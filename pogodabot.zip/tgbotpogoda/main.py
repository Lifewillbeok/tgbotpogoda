import telebot
from telebot import types
import requests

bot = telebot.TeleBot('7701590819:AAGIz32hvdpeDjpNlsm1nGpkjPyqGiMio88')

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def startBot(message):
    first_mess = f"<b>{message.from_user.first_name}</b>, привет!\nХочешь расскажу немного о погоде?"
    markup = types.InlineKeyboardMarkup()
    button_yes = types.InlineKeyboardButton(text='Да', callback_data='yes')
    markup.add(button_yes)
    bot.send_message(message.chat.id, first_mess, parse_mode='html', reply_markup=markup)

# Обработчик коллбеков
@bot.callback_query_handler(func=lambda call: True)
def response(function_call):
    if function_call.data == "yes":
        second_mess = "Напиши свой город, в котором хочешь узнать погоду!"
        bot.send_message(function_call.message.chat.id, second_mess)
    bot.answer_callback_query(function_call.id)

@bot.message_handler(content_types=['text'])
def get_weather(message: types.Message):
    city_name = message.text  # Получаем название города от пользователя
    api_key = '921ee8a869b02469c63eb8f9012ba0ed'
    try:
        # Отправляем запрос к API с названием города
        response = requests.get(f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&lang=ru&units=metric&appid={api_key}")
        data = response.json()

        if data.get("cod") != 200:  # Если город не найден, API возвращает ошибку
            bot.send_message(message.chat.id, "Проверьте название города!")
            return

        # Получаем данные о погоде
        city = data["name"]
        cur_temp = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        cur_weather = data["weather"][0]["description"]

        # Формируем ответ
        weather_info = (f"Погода в {city}:\n"
                        f"Температура: {cur_temp}°C\n"
                        f"Влажность: {humidity}%\n"
                        f"Состояние погоды: {cur_weather.capitalize()}")

        bot.send_message(message.chat.id, weather_info)
    except Exception as e:
        bot.send_message(message.chat.id, "Произошла ошибка при запросе погоды!")
        print(e)  # Вывод ошибки в консоль для отладки

# Бесконечный цикл для получения обновлений
bot.infinity_polling()
